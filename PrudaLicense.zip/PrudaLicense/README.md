# PrudaTweak Licensing System

A complete licensing system with HWID-lock capability and Discord integration for distributing licenses for your application.

## Components

1. **Web Dashboard**: Management interface for generating and managing licenses
2. **Python Client**: Client-side script with HWID locking and the PrudaTweak functionality 
3. **Discord Integration**: Discord bot/webhook for automatic license distribution

## Setup Instructions

### 1. Web Dashboard Setup

1. Clone this repository to your server
2. Install dependencies:
   ```
   npm install
   ```
3. Start the server:
   ```
   npm run dev
   ```
4. Access the dashboard at http://localhost:5000

### 2. Discord Bot Setup

To enable Discord integration for sending licenses to users:

1. Go to the [Discord Developer Portal](https://discord.com/developers/applications)
2. Create a new application
3. Navigate to the "Bot" section and click "Add Bot"
4. Copy the bot token
5. In the dashboard, go to "Discord Integration" and paste your bot token
6. Enable the "OAuth2" section and select bot permissions:
   - Send Messages
   - Read Message History
   - Add Reactions
   - Manage Roles (if you want to assign roles to users with licenses)
7. Invite the bot to your server using the generated OAuth2 URL

### Discord Webhook Setup (Alternative to Bot)

If you prefer using webhooks instead of a bot:

1. Go to your Discord server
2. Edit a channel -> Integrations -> Create Webhook
3. Copy the webhook URL
4. In the dashboard, go to "Discord Integration" and paste your webhook URL

### 3. Python Client Setup

1. Navigate to the `client_script` directory
2. Run the installation script:
   ```
   install_requirements.bat
   ```
3. Make sure the licensing server is running
4. Run the client script:
   ```
   venv\Scripts\python.exe pruda_client.py
   ```
5. Enter your license key when prompted

## Usage Instructions

### License Management

1. Login to the dashboard
2. Go to "License Management"
3. Click "Generate License" to create new licenses
4. Specify license parameters:
   - Duration
   - Discord Username (optional)
   - HWID Lock settings
   - Features

### Discord Commands

The following commands are available in your Discord server:

- `!license check` - Check your current license status
- `!license activate <key>` - Activate a license with your Discord account

### Admin Commands

For Discord users with admin privileges:

- `!license generate <user> <days>` - Generate a license for a user
- `!license revoke <key>` - Revoke a license
- `!license list` - List all active licenses

## HWID Lock Functionality

The PrudaTweak script:
1. Generates a unique hardware ID for the user's device
2. Securely verifies the license against the server
3. Activates the license with the user's HWID
4. Enables the Pruda tweak features when right mouse button is held

## Hotkeys

- `^` (caret) - Toggle the script on/off
- `END` - Exit the script

## Security Features

- License keys are HWID-locked by default
- Licenses can be generated with expiration dates
- Discord integration for secure license distribution
- Revocation capability for compromised licenses