import random
import threading
import time
import pyautogui
pyautogui.FAILSAFE = False  # Failsafe deaktivieren
import keyboard
from pynput.mouse import Listener, Button
import os
from pystray import Icon, MenuItem, Menu
from PIL import Image, ImageDraw

version = "1.0.3"
running = True
alive = True
right_mouse_pressed = False

# Hotkeys
kill_script_keybind = "end"
toggle_running_keybind = "^"

# Screen center
x, y = pyautogui.size().width // 2, pyautogui.size().height // 2

# Red color style
RED = "\033[91m"
RESET = "\033[0m"

# Error logging
def log_error(message):
    with open("error_log.txt", "a") as log_file:
        log_file.write(f"{time.ctime()} - ERROR: {message}\n")

# Tray icon creation
def create_tray_icon():
    def create_image(color):
        image = Image.new("RGB", (64, 64), color)
        draw = ImageDraw.Draw(image)
        return image

    def update_icon():
        icon.icon = create_image("green" if running else "red")

    def toggle_running(icon, item):
        global running
        running = not running
        update_icon()

    def exit_script(icon, item):
        kill_script()

    menu = Menu(
        MenuItem("Toggle Script", toggle_running),
        MenuItem("Exit", exit_script)
    )

    icon = Icon("Mechvipes", create_image("red"), "Mechvipes", menu)
    update_icon()
    icon.run()

# Mouse click detection
def on_click(x, y, button, pressed):
    global right_mouse_pressed
    if button == Button.right:
        right_mouse_pressed = pressed

mouse_listener = Listener(on_click=on_click)
mouse_listener.start()

# Main check loop
def check():
    while alive:
        if running and right_mouse_pressed:
            try:
                screen_width, screen_height = pyautogui.size()
                if x < 0 or y < 0 or x >= screen_width or y >= screen_height:
                    raise ValueError("Coordinates out of screen bounds.")

                color = pyautogui.pixel(x, y)
                r, g, b = color
                if r >= 180 and g < 100 and b < 100:
                    pyautogui.mouseDown()
                    time.sleep(random.uniform(0.001, 0.005))
                    pyautogui.mouseUp()
            except Exception as e:
                log_error(f"Color check error: {e}")
                print(f"{RED}Error during color check: {e}{RESET}")
        time.sleep(0)

# Hotkey setup
def setup_hotkeys():
    keyboard.add_hotkey(toggle_running_keybind, toggle_running_action)
    keyboard.add_hotkey(kill_script_keybind, kill_script)
    keyboard.wait()

# Toggle script status
def toggle_running_action():
    global running
    running = not running
    print(f"{RED}Script {'started' if running else 'paused'}{RESET}")

# Kill script
def kill_script():
    global alive
    alive = False
    mouse_listener.stop()
    print(f"{RED}Exiting script...{RESET}")
    os._exit(0)

print(f"[TWEAK] Pruda Tweak [V1] ...{RESET}")
icon_thread = threading.Thread(target=create_tray_icon, daemon=True)
icon_thread.start()

check_thread = threading.Thread(target=check, daemon=True)
check_thread.start()

setup_hotkeys()
