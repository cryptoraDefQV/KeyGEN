import crypto from "crypto";

/**
 * Generates a unique license key in the format PRUDA-XXXX-XXXX-XXXX
 * where X is an alphanumeric character (excluding ambiguous characters)
 */
export function generateLicenseKey(): string {
  // Define the character set (excluding ambiguous characters like 0/O, 1/I, etc.)
  const validChars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  
  // Generate 3 groups of 4 characters
  const group1 = generateRandomString(4, validChars);
  const group2 = generateRandomString(4, validChars);
  const group3 = generateRandomString(4, validChars);
  
  // Format as PRUDA-XXXX-XXXX-XXXX
  return `PRUDA-${group1}-${group2}-${group3}`;
}

/**
 * Generate a random string of specified length using the provided character set
 */
function generateRandomString(length: number, chars: string): string {
  let result = "";
  const randomBytes = crypto.randomBytes(length);
  
  for (let i = 0; i < length; i++) {
    const randomIndex = randomBytes[i] % chars.length;
    result += chars.charAt(randomIndex);
  }
  
  return result;
}

/**
 * Encrypts a license key with a secret for secure transmission
 */
export function encryptLicenseKey(licenseKey: string, secret: string): string {
  const iv = crypto.randomBytes(16);
  const key = crypto.createHash("sha256").update(secret).digest().slice(0, 32);
  const cipher = crypto.createCipheriv("aes-256-cbc", key, iv);
  
  let encrypted = cipher.update(licenseKey, "utf8", "hex");
  encrypted += cipher.final("hex");
  
  return iv.toString("hex") + ":" + encrypted;
}

/**
 * Decrypts an encrypted license key
 */
export function decryptLicenseKey(encryptedLicense: string, secret: string): string {
  const [ivHex, encryptedHex] = encryptedLicense.split(":");
  const iv = Buffer.from(ivHex, "hex");
  const key = crypto.createHash("sha256").update(secret).digest().slice(0, 32);
  const decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);
  
  let decrypted = decipher.update(encryptedHex, "hex", "utf8");
  decrypted += decipher.final("utf8");
  
  return decrypted;
}
