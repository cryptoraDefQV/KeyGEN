/**
 * Validates a hardware ID (HWID) format
 * Valid formats:
 * - Hyphen separated segments: XX-XX-XX-XX
 * - Colon separated segments: XX:XX:XX:XX
 * - Hash format: XXXXXXXXXXXXXXXX
 */
export function validateHwid(hwid: string): boolean {
  // Check for common HWID formats
  const hyphenFormat = /^[A-F0-9]{2}(-[A-F0-9]{2}){3,7}$/i;
  const colonFormat = /^[A-F0-9]{2}(:[A-F0-9]{2}){3,7}$/i;
  const hashFormat = /^[A-F0-9]{16,64}$/i;
  
  return hyphenFormat.test(hwid) || colonFormat.test(hwid) || hashFormat.test(hwid);
}

/**
 * Normalizes a hardware ID to a standard format
 * This can be used to compare HWIDs that might be in different formats
 */
export function normalizeHwid(hwid: string): string {
  // Remove all separators and convert to uppercase
  return hwid.replace(/[-:]/g, '').toUpperCase();
}

/**
 * Formats a hardware ID for display purposes (adds hyphens)
 */
export function formatHwid(hwid: string): string {
  const normalized = normalizeHwid(hwid);
  
  // Format as XX-XX-XX-XX
  let formatted = '';
  for (let i = 0; i < normalized.length; i += 2) {
    if (i > 0) formatted += '-';
    formatted += normalized.substr(i, 2);
  }
  
  return formatted;
}

/**
 * Obscures part of the HWID for display purposes
 * E.g., 4C-8B-1A-D7 becomes 4C-8B-**-**
 */
export function obscureHwid(hwid: string): string {
  const parts = hwid.split(/[-:]/);
  if (parts.length < 3) return hwid;
  
  // Keep the first half visible, obscure the rest
  const visibleCount = Math.ceil(parts.length / 2);
  const obscuredParts = parts.map((part, index) => 
    index < visibleCount ? part : '**'
  );
  
  return obscuredParts.join('-');
}
