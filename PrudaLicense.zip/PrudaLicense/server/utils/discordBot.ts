import { storage } from "../storage";

// Environment variables are already loaded in the server

/**
 * Sends a license key to a Discord user via webhook or bot
 */
export async function sendLicenseToDiscord(
  discordUsername: string,
  licenseKey: string,
  expiresAt: Date
): Promise<void> {
  // Get Discord integration configuration
  const discordConfig = await storage.getDiscordIntegration();
  const botToken = process.env.DISCORD_BOT_TOKEN || (discordConfig?.botToken || "");
  
  if ((!discordConfig || !discordConfig.isEnabled) && !botToken) {
    console.log("Discord integration not enabled or configured.");
    return;
  }
  
  // Format expiration date
  const expiryFormatted = expiresAt.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  
  const webhookUrl = discordConfig?.webhookUrl || "";
  
  if (webhookUrl) {
    // Use webhook to send the license (simpler approach)
    try {
      const message = {
        embeds: [
          {
            title: "PrudaTweak License Generated",
            description: `Your license has been generated and is ready to use.`,
            color: 0x0078D4, // Primary blue color
            fields: [
              {
                name: "License Key",
                value: `\`${licenseKey}\``,
                inline: false
              },
              {
                name: "Expires",
                value: expiryFormatted,
                inline: true
              },
              {
                name: "Status",
                value: "Pending Activation",
                inline: true
              }
            ],
            footer: {
              text: "PrudaTweak License Manager"
            },
            timestamp: new Date().toISOString()
          }
        ]
      };
      
      await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(message)
      });
      
      console.log(`License sent to Discord webhook for user: ${discordUsername}`);
    } catch (error) {
      console.error("Error sending license to Discord webhook:", error);
      throw new Error("Failed to send license to Discord webhook");
    }
  } else if (botToken) {
    // For a proper implementation, you would use the Discord.js library
    // Here we just log the attempt and provide the bot token to the separate Python bot
    console.log(`Discord bot would send license ${licenseKey} to ${discordUsername}`);
    
    // For this implementation, we'll just log the attempt
    // In a real implementation with a separate Python bot, you would send the data via a more reliable method
    
    // Create a log entry with the license info
    const licenseInfo = {
      username: discordUsername,
      licenseKey: licenseKey,
      expiresAt: expiresAt.toISOString(),
      timestamp: new Date().toISOString()
    };
    
    console.log(`Discord bot would send license ${licenseKey} to ${discordUsername}`);
    console.log(`License details: ${JSON.stringify(licenseInfo)}`);
    
    // For a production implementation, you might use a database, queue system, or API to communicate with the bot
    } catch (error) {
      console.error("Error saving license info for Discord bot:", error);
    }
  } else {
    throw new Error("No Discord webhook URL or bot token configured");
  }
}

/**
 * Notifies about license status changes via Discord
 */
export async function notifyLicenseStatusChange(
  licenseKey: string,
  status: string,
  discordUsername?: string
): Promise<void> {
  // Get Discord integration configuration
  const discordConfig = await storage.getDiscordIntegration();
  
  if (!discordConfig || !discordConfig.isEnabled) {
    return;
  }
  
  const webhookUrl = discordConfig?.webhookUrl || "";
  
  if (!webhookUrl) {
    return;
  }
  
  // Map status to color
  const statusColors = {
    active: 0x107C10, // Green
    pending: 0xF8CD46, // Yellow/Gold
    expired: 0xD83B01, // Red/Orange
    revoked: 0xD83B01  // Red/Orange
  };
  
  const color = statusColors[status as keyof typeof statusColors] || 0x797775; // Default to gray
  
  try {
    const message = {
      embeds: [
        {
          title: "License Status Changed",
          description: `License ${licenseKey} status changed to ${status}`,
          color,
          fields: [
            {
              name: "License Key",
              value: `\`${licenseKey}\``,
              inline: true
            },
            {
              name: "Status",
              value: status.charAt(0).toUpperCase() + status.slice(1),
              inline: true
            }
          ],
          footer: {
            text: "PrudaTweak License Manager"
          },
          timestamp: new Date().toISOString()
        }
      ]
    };
    
    if (discordUsername) {
      message.embeds[0].fields.push({
        name: "User",
        value: discordUsername,
        inline: true
      });
    }
    
    await fetch(webhookUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(message)
    });
  } catch (error) {
    console.error("Error sending license status change to Discord:", error);
  }
}
