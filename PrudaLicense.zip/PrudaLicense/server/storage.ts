import { 
  users, 
  type User, 
  type InsertUser, 
  licenses, 
  type License, 
  type InsertLicense,
  discordIntegration,
  type DiscordIntegration,
  type InsertDiscordIntegration,
  settings,
  type Settings,
  type InsertSettings
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByDiscordId(discordId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;

  // License methods
  getLicense(id: number): Promise<License | undefined>;
  getLicenseByKey(licenseKey: string): Promise<License | undefined>;
  getLicensesByUserId(userId: number): Promise<License[]>;
  createLicense(license: InsertLicense): Promise<License>;
  updateLicense(id: number, license: Partial<License>): Promise<License | undefined>;
  deleteLicense(id: number): Promise<boolean>;
  getAllLicenses(): Promise<License[]>;
  getActiveCount(): Promise<number>;
  getPendingCount(): Promise<number>;
  getExpiredCount(): Promise<number>;
  getTotalCount(): Promise<number>;

  // Discord integration methods
  getDiscordIntegration(): Promise<DiscordIntegration | undefined>;
  saveDiscordIntegration(integration: InsertDiscordIntegration): Promise<DiscordIntegration>;
  updateDiscordIntegration(integration: Partial<DiscordIntegration>): Promise<DiscordIntegration | undefined>;

  // Settings methods
  getSetting(key: string): Promise<Settings | undefined>;
  saveSetting(key: string, value: string): Promise<Settings>;
  getAllSettings(): Promise<Settings[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private licenses: Map<number, License>;
  private discordIntegration: DiscordIntegration | undefined;
  private settings: Map<string, Settings>;
  private currentUserId: number;
  private currentLicenseId: number;
  private currentSettingId: number;

  constructor() {
    this.users = new Map();
    this.licenses = new Map();
    this.settings = new Map();
    this.currentUserId = 1;
    this.currentLicenseId = 1;
    this.currentSettingId = 1;

    // Initialize with admin user
    this.createUser({
      username: "admin",
      password: "admin",
      discordId: "",
      discordUsername: "",
      email: "admin@prudatweak.com",
      isAdmin: true
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByDiscordId(discordId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.discordId === discordId,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // License methods
  async getLicense(id: number): Promise<License | undefined> {
    return this.licenses.get(id);
  }

  async getLicenseByKey(licenseKey: string): Promise<License | undefined> {
    return Array.from(this.licenses.values()).find(
      (license) => license.licenseKey === licenseKey,
    );
  }

  async getLicensesByUserId(userId: number): Promise<License[]> {
    return Array.from(this.licenses.values()).filter(
      (license) => license.userId === userId,
    );
  }

  async createLicense(insertLicense: InsertLicense): Promise<License> {
    const id = this.currentLicenseId++;
    const license: License = { 
      ...insertLicense, 
      id, 
      createdAt: new Date(),
      activatedAt: null
    };
    this.licenses.set(id, license);
    return license;
  }

  async updateLicense(id: number, licenseData: Partial<License>): Promise<License | undefined> {
    const license = await this.getLicense(id);
    if (!license) return undefined;
    
    const updatedLicense = { ...license, ...licenseData };
    this.licenses.set(id, updatedLicense);
    return updatedLicense;
  }

  async deleteLicense(id: number): Promise<boolean> {
    return this.licenses.delete(id);
  }

  async getAllLicenses(): Promise<License[]> {
    return Array.from(this.licenses.values());
  }

  async getActiveCount(): Promise<number> {
    return Array.from(this.licenses.values()).filter(
      (license) => license.status === "active"
    ).length;
  }

  async getPendingCount(): Promise<number> {
    return Array.from(this.licenses.values()).filter(
      (license) => license.status === "pending"
    ).length;
  }

  async getExpiredCount(): Promise<number> {
    return Array.from(this.licenses.values()).filter(
      (license) => license.status === "expired"
    ).length;
  }

  async getTotalCount(): Promise<number> {
    return this.licenses.size;
  }

  // Discord integration methods
  async getDiscordIntegration(): Promise<DiscordIntegration | undefined> {
    return this.discordIntegration;
  }

  async saveDiscordIntegration(integration: InsertDiscordIntegration): Promise<DiscordIntegration> {
    const newIntegration: DiscordIntegration = { 
      ...integration, 
      id: 1 
    };
    this.discordIntegration = newIntegration;
    return newIntegration;
  }

  async updateDiscordIntegration(integrationData: Partial<DiscordIntegration>): Promise<DiscordIntegration | undefined> {
    if (!this.discordIntegration) return undefined;
    
    this.discordIntegration = { ...this.discordIntegration, ...integrationData };
    return this.discordIntegration;
  }

  // Settings methods
  async getSetting(key: string): Promise<Settings | undefined> {
    return this.settings.get(key);
  }

  async saveSetting(key: string, value: string): Promise<Settings> {
    const existingSetting = await this.getSetting(key);
    
    if (existingSetting) {
      const updatedSetting = { ...existingSetting, value };
      this.settings.set(key, updatedSetting);
      return updatedSetting;
    }
    
    const id = this.currentSettingId++;
    const newSetting: Settings = { id, key, value };
    this.settings.set(key, newSetting);
    return newSetting;
  }

  async getAllSettings(): Promise<Settings[]> {
    return Array.from(this.settings.values());
  }
}

export const storage = new MemStorage();
