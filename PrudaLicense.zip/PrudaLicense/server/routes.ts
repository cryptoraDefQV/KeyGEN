import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  generateLicenseSchema, 
  verifyLicenseSchema, 
  activateLicenseSchema,
  insertLicenseSchema,
  insertUserSchema
} from "@shared/schema";
import { generateLicenseKey } from "./utils/licenseGenerator";
import { sendLicenseToDiscord } from "./utils/discordBot";
import { validateHwid } from "./utils/hwidUtils";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const apiRouter = express.Router();

  // Error handling middleware
  const handleError = (err: any, res: Response) => {
    console.error(err);
    if (err instanceof ZodError) {
      return res.status(400).json({ 
        message: "Validation error", 
        errors: fromZodError(err).message 
      });
    }
    return res.status(500).json({ message: err.message || "Internal server error" });
  };

  // License endpoints
  apiRouter.get("/licenses", async (req: Request, res: Response) => {
    try {
      const licenses = await storage.getAllLicenses();
      res.json(licenses);
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.get("/licenses/stats", async (req: Request, res: Response) => {
    try {
      const [totalCount, activeCount, pendingCount, expiredCount] = await Promise.all([
        storage.getTotalCount(),
        storage.getActiveCount(),
        storage.getPendingCount(),
        storage.getExpiredCount()
      ]);
      
      res.json({
        totalCount,
        activeCount,
        pendingCount,
        expiredCount
      });
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.get("/licenses/:id", async (req: Request, res: Response) => {
    try {
      const license = await storage.getLicense(Number(req.params.id));
      if (!license) {
        return res.status(404).json({ message: "License not found" });
      }
      res.json(license);
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.post("/licenses/verify", async (req: Request, res: Response) => {
    try {
      const data = verifyLicenseSchema.parse(req.body);
      const license = await storage.getLicenseByKey(data.licenseKey);
      
      if (!license) {
        return res.status(404).json({ 
          valid: false, 
          message: "Invalid license key" 
        });
      }

      // Check if license is expired
      if (license.status === "expired" || (license.expiresAt && new Date() > license.expiresAt)) {
        await storage.updateLicense(license.id, { status: "expired" });
        return res.status(400).json({ 
          valid: false, 
          message: "License has expired" 
        });
      }

      // Check if license is revoked
      if (license.status === "revoked") {
        return res.status(400).json({ 
          valid: false, 
          message: "License has been revoked" 
        });
      }

      // Check HWID if provided and license is HWID locked
      if (data.hwid && license.isHwidLocked) {
        if (!license.hwid) {
          // License hasn't been activated with an HWID yet
          return res.json({ 
            valid: true, 
            activated: false,
            status: license.status,
            message: "License valid but not activated with HWID" 
          });
        }
        
        if (license.hwid !== data.hwid) {
          return res.status(400).json({ 
            valid: false, 
            message: "HWID mismatch" 
          });
        }
      }

      res.json({ 
        valid: true,
        activated: !!license.hwid,
        status: license.status,
        expires: license.expiresAt,
        features: JSON.parse(license.features)
      });
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.post("/licenses/activate", async (req: Request, res: Response) => {
    try {
      const data = activateLicenseSchema.parse(req.body);
      const license = await storage.getLicenseByKey(data.licenseKey);
      
      if (!license) {
        return res.status(404).json({ message: "Invalid license key" });
      }

      // Validate HWID
      if (!validateHwid(data.hwid)) {
        return res.status(400).json({ message: "Invalid HWID format" });
      }

      // Check if license is expired
      if (license.status === "expired" || (license.expiresAt && new Date() > license.expiresAt)) {
        await storage.updateLicense(license.id, { status: "expired" });
        return res.status(400).json({ message: "License has expired" });
      }

      // Check if license is revoked
      if (license.status === "revoked") {
        return res.status(400).json({ message: "License has been revoked" });
      }

      // Check if license is already activated with a different HWID
      if (license.hwid && license.hwid !== data.hwid && license.isHwidLocked) {
        return res.status(400).json({ message: "License already activated with a different HWID" });
      }

      // Activate the license
      const updatedLicense = await storage.updateLicense(license.id, {
        hwid: data.hwid,
        status: "active",
        activatedAt: new Date()
      });

      res.json({
        success: true,
        license: updatedLicense
      });
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.post("/licenses/generate", async (req: Request, res: Response) => {
    try {
      const data = generateLicenseSchema.parse(req.body);
      
      // Generate a unique license key
      const licenseKey = generateLicenseKey();
      
      // Calculate expiration date based on license type
      let expiresAt = new Date();
      if (data.licenseType === "standard") {
        expiresAt.setDate(expiresAt.getDate() + 30); // 30 days
      } else if (data.licenseType === "premium") {
        expiresAt.setDate(expiresAt.getDate() + 90); // 90 days
      } else if (data.licenseType === "annual") {
        expiresAt.setFullYear(expiresAt.getFullYear() + 1); // 1 year
      } else if (data.licenseType === "custom" && data.duration && data.durationType) {
        if (data.durationType === "days") {
          expiresAt.setDate(expiresAt.getDate() + data.duration);
        } else if (data.durationType === "months") {
          expiresAt.setMonth(expiresAt.getMonth() + data.duration);
        } else if (data.durationType === "years") {
          expiresAt.setFullYear(expiresAt.getFullYear() + data.duration);
        }
      }

      // Determine if HWID locking is required
      const isHwidLocked = data.hwidLock === "required" || data.hwidLock === "optional";
      
      // Create license in storage
      const licenseData = insertLicenseSchema.parse({
        licenseKey,
        isHwidLocked,
        status: "pending",
        features: JSON.stringify(data.features),
        expiresAt
      });
      
      // If discordUsername is provided, find or create the user
      let userId = undefined;
      if (data.discordUsername) {
        const user = await storage.getUserByDiscordId(data.discordUsername);
        if (user) {
          userId = user.id;
        } else {
          // Create a new user with the Discord username
          const newUser = await storage.createUser({
            username: data.discordUsername,
            password: "", // No password for Discord users
            discordId: data.discordUsername,
            discordUsername: data.discordUsername,
            email: "",
            isAdmin: false
          });
          userId = newUser.id;
        }
      }

      const license = await storage.createLicense({
        ...licenseData,
        userId
      });

      // Send license to Discord if applicable
      if (data.discordUsername) {
        try {
          await sendLicenseToDiscord(data.discordUsername, licenseKey, expiresAt);
        } catch (discordErr) {
          console.error("Failed to send license to Discord:", discordErr);
          // Continue execution, don't fail the license generation
        }
      }

      res.json({
        success: true,
        license
      });
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.put("/licenses/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      const license = await storage.getLicense(id);
      
      if (!license) {
        return res.status(404).json({ message: "License not found" });
      }
      
      const updatedLicense = await storage.updateLicense(id, req.body);
      res.json(updatedLicense);
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.delete("/licenses/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      const deleted = await storage.deleteLicense(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "License not found" });
      }
      
      res.json({ success: true });
    } catch (err) {
      handleError(err, res);
    }
  });

  // User endpoints
  apiRouter.get("/users", async (req: Request, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.get("/users/:id", async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(Number(req.params.id));
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.post("/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.put("/users/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      const user = await storage.getUser(id);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(id, req.body);
      res.json(updatedUser);
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.delete("/users/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      const deleted = await storage.deleteUser(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ success: true });
    } catch (err) {
      handleError(err, res);
    }
  });

  // Discord integration endpoints
  apiRouter.get("/discord", async (req: Request, res: Response) => {
    try {
      const discord = await storage.getDiscordIntegration();
      res.json(discord || { isEnabled: false });
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.post("/discord", async (req: Request, res: Response) => {
    try {
      const integration = await storage.saveDiscordIntegration(req.body);
      res.json(integration);
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.put("/discord", async (req: Request, res: Response) => {
    try {
      const integration = await storage.updateDiscordIntegration(req.body);
      
      if (!integration) {
        return res.status(404).json({ message: "Discord integration not found" });
      }
      
      res.json(integration);
    } catch (err) {
      handleError(err, res);
    }
  });

  // Settings endpoints
  apiRouter.get("/settings", async (req: Request, res: Response) => {
    try {
      const settings = await storage.getAllSettings();
      res.json(settings);
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.get("/settings/:key", async (req: Request, res: Response) => {
    try {
      const setting = await storage.getSetting(req.params.key);
      
      if (!setting) {
        return res.status(404).json({ message: "Setting not found" });
      }
      
      res.json(setting);
    } catch (err) {
      handleError(err, res);
    }
  });

  apiRouter.post("/settings/:key", async (req: Request, res: Response) => {
    try {
      const { value } = req.body;
      
      if (value === undefined) {
        return res.status(400).json({ message: "Value is required" });
      }
      
      const setting = await storage.saveSetting(req.params.key, value);
      res.json(setting);
    } catch (err) {
      handleError(err, res);
    }
  });

  // Add the API router
  app.use("/api", apiRouter);

  return httpServer;
}
