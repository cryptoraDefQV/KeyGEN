import { pgTable, text, serial, integer, boolean, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  discordId: text("discord_id"),
  discordUsername: text("discord_username"),
  email: text("email"),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  discordId: true,
  discordUsername: true,
  email: true,
  isAdmin: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const licenses = pgTable("licenses", {
  id: serial("id").primaryKey(),
  licenseKey: text("license_key").notNull().unique(),
  userId: integer("user_id").references(() => users.id),
  hwid: text("hwid"),
  isHwidLocked: boolean("is_hwid_locked").default(true),
  status: text("status").notNull().default("pending"), // pending, active, expired, revoked
  features: text("features").notNull().default("{}"),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at"),
  activatedAt: timestamp("activated_at"),
});

export const insertLicenseSchema = createInsertSchema(licenses).pick({
  licenseKey: true,
  userId: true,
  hwid: true,
  isHwidLocked: true,
  status: true,
  features: true,
  expiresAt: true,
});

export type InsertLicense = z.infer<typeof insertLicenseSchema>;
export type License = typeof licenses.$inferSelect;

export const discordIntegration = pgTable("discord_integration", {
  id: serial("id").primaryKey(),
  botToken: text("bot_token"),
  webhookUrl: text("webhook_url"),
  serverId: text("server_id"),
  licenseRoleId: text("license_role_id"),
  adminRoleId: text("admin_role_id"),
  isEnabled: boolean("is_enabled").default(false),
});

export const insertDiscordIntegrationSchema = createInsertSchema(discordIntegration).pick({
  botToken: true,
  webhookUrl: true,
  serverId: true, 
  licenseRoleId: true,
  adminRoleId: true,
  isEnabled: true,
});

export type InsertDiscordIntegration = z.infer<typeof insertDiscordIntegrationSchema>;
export type DiscordIntegration = typeof discordIntegration.$inferSelect;

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
});

export const insertSettingsSchema = createInsertSchema(settings);

export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settings.$inferSelect;

// Frontend schemas
export const generateLicenseSchema = z.object({
  licenseType: z.enum(["standard", "premium", "annual", "custom"]),
  discordUsername: z.string().optional(),
  hwidLock: z.enum(["required", "optional", "none"]),
  duration: z.number().optional(),
  durationType: z.enum(["days", "months", "years"]).optional(),
  features: z.object({
    scriptAccess: z.boolean().default(true),
    prioritySupport: z.boolean().default(false),
    betaFeatures: z.boolean().default(false),
  }),
});

export type GenerateLicenseInput = z.infer<typeof generateLicenseSchema>;

export const verifyLicenseSchema = z.object({
  licenseKey: z.string().min(16).max(32),
  hwid: z.string().optional(),
});

export type VerifyLicenseInput = z.infer<typeof verifyLicenseSchema>;

export const activateLicenseSchema = z.object({
  licenseKey: z.string().min(16).max(32),
  hwid: z.string().min(4),
});

export type ActivateLicenseInput = z.infer<typeof activateLicenseSchema>;
