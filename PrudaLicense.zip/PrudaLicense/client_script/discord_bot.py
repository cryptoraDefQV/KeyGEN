import discord
from discord.ext import commands
import requests
import os
import json
import asyncio
import datetime

# Configuration
TOKEN = os.environ.get("DISCORD_BOT_TOKEN")  # Get token from environment variable
API_URL = "http://localhost:5000/api"  # Replace with your server URL
CONFIG_FILE = "bot_config.json"

# Bot setup
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

# Config functions
def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return {
        "admin_role_id": None,
        "license_role_id": None,
        "webhook_url": None
    }

def save_config(config):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=4)

config = load_config()

@bot.event
async def on_ready():
    print(f"Bot logged in as {bot.user.name} ({bot.user.id})")
    print("------")

# License commands
@bot.command(name="license")
async def license_command(ctx, action=None, *args):
    if action is None:
        await ctx.send("```\nLicense Commands:\n!license check - Check your license status\n!license activate <key> - Activate a license\n!license help - Show this help message\n```")
        return

    if action.lower() == "help":
        embed = discord.Embed(
            title="License Bot Commands",
            description="Here are the available commands:",
            color=0x0078D4
        )
        embed.add_field(name="!license check", value="Check your license status", inline=False)
        embed.add_field(name="!license activate <key>", value="Activate a license with your Discord account", inline=False)
        
        # Admin commands
        is_admin = ctx.author.guild_permissions.administrator or \
                  (config["admin_role_id"] and any(role.id == config["admin_role_id"] for role in ctx.author.roles))
        
        if is_admin:
            embed.add_field(name="Admin Commands", value="The following commands are available to admins:", inline=False)
            embed.add_field(name="!license generate <user> <days>", value="Generate a license for a user", inline=False)
            embed.add_field(name="!license revoke <key>", value="Revoke a license", inline=False)
            embed.add_field(name="!license list", value="List all active licenses", inline=False)
        
        await ctx.send(embed=embed)
        return

    if action.lower() == "check":
        # Get user's licenses by Discord ID
        try:
            # This is a placeholder - in a real implementation, you would query the API
            # using the user's Discord ID to find their licenses
            response = requests.get(f"{API_URL}/users/discord/{ctx.author.id}")
            if response.status_code == 200:
                user_data = response.json()
                if user_data.get("licenses") and len(user_data["licenses"]) > 0:
                    embed = discord.Embed(
                        title="Your License Information",
                        color=0x107C10  # Green
                    )
                    
                    for license in user_data["licenses"]:
                        status_emoji = "✅" if license["status"] == "active" else "⚠️"
                        expiry_date = datetime.datetime.fromisoformat(license["expiresAt"].replace('Z', '+00:00')) if license["expiresAt"] else "Never"
                        expiry_str = expiry_date if isinstance(expiry_date, str) else expiry_date.strftime("%Y-%m-%d")
                        
                        embed.add_field(
                            name=f"{status_emoji} License: {license['licenseKey']}",
                            value=f"Status: {license['status'].capitalize()}\nExpires: {expiry_str}",
                            inline=False
                        )
                    
                    await ctx.send(embed=embed)
                else:
                    await ctx.send("You don't have any licenses associated with your Discord account.")
            else:
                await ctx.send("Could not retrieve license information. Please try again later.")
        except Exception as e:
            print(f"Error checking license: {e}")
            await ctx.send("An error occurred while checking your license.")
        
        return

    if action.lower() == "activate":
        if len(args) == 0:
            await ctx.send("Please provide a license key. Usage: `!license activate PRUDA-XXXX-XXXX-XXXX`")
            return
        
        license_key = args[0]
        
        # In a real implementation, you would validate the license key format
        if not license_key.startswith("PRUDA-") or len(license_key) < 16:
            await ctx.send("Invalid license key format. License keys should look like: `PRUDA-XXXX-XXXX-XXXX`")
            return
        
        try:
            # This is a placeholder - in a real implementation, you would send the activation request to the API
            response = requests.post(f"{API_URL}/licenses/activate", json={
                "licenseKey": license_key,
                "discordId": str(ctx.author.id),
                "discordUsername": f"{ctx.author.name}#{ctx.author.discriminator}"
            })
            
            if response.status_code == 200:
                data = response.json()
                if data.get("success"):
                    # If license role is configured, assign it to the user
                    if config["license_role_id"]:
                        role = ctx.guild.get_role(config["license_role_id"])
                        if role:
                            await ctx.author.add_roles(role)
                    
                    embed = discord.Embed(
                        title="License Activated",
                        description="Your license has been successfully activated!",
                        color=0x107C10  # Green
                    )
                    await ctx.send(embed=embed)
                else:
                    await ctx.send(f"License activation failed: {data.get('message', 'Unknown error')}")
            else:
                data = response.json()
                await ctx.send(f"License activation failed: {data.get('message', 'Unknown error')}")
        except Exception as e:
            print(f"Error activating license: {e}")
            await ctx.send("An error occurred while activating your license.")
        
        return

    # Admin commands
    is_admin = ctx.author.guild_permissions.administrator or \
              (config["admin_role_id"] and any(role.id == config["admin_role_id"] for role in ctx.author.roles))
    
    if not is_admin:
        await ctx.send("You don't have permission to use this command.")
        return
    
    if action.lower() == "generate":
        if len(args) < 2:
            await ctx.send("Usage: `!license generate <user> <days>`")
            return
        
        user_mention = args[0]
        try:
            days = int(args[1])
        except ValueError:
            await ctx.send("Days must be a number.")
            return
        
        # Extract user ID from mention
        user_id = user_mention.strip("<@!>")
        if not user_id.isdigit():
            await ctx.send("Invalid user mention.")
            return
        
        try:
            # Get the user from the guild
            user = await ctx.guild.fetch_member(int(user_id))
            if not user:
                await ctx.send("User not found in this server.")
                return
            
            # Generate license
            response = requests.post(f"{API_URL}/licenses/generate", json={
                "licenseType": "custom",
                "duration": days,
                "durationType": "days",
                "discordUsername": f"{user.name}#{user.discriminator}",
                "hwidLock": "required",
                "features": {
                    "scriptAccess": True,
                    "prioritySupport": True,
                    "betaFeatures": False
                }
            })
            
            if response.status_code == 200:
                data = response.json()
                license_key = data["license"]["licenseKey"]
                
                embed = discord.Embed(
                    title="License Generated",
                    description=f"A license has been generated for {user.mention}",
                    color=0x0078D4
                )
                embed.add_field(name="License Key", value=f"`{license_key}`", inline=False)
                embed.add_field(name="Duration", value=f"{days} days", inline=True)
                embed.add_field(name="Status", value="Pending Activation", inline=True)
                
                await ctx.send(embed=embed)
                
                # Send DM to user
                try:
                    user_embed = discord.Embed(
                        title="Your PrudaTweak License",
                        description="A license has been generated for you!",
                        color=0x0078D4
                    )
                    user_embed.add_field(name="License Key", value=f"`{license_key}`", inline=False)
                    user_embed.add_field(name="Duration", value=f"{days} days", inline=True)
                    user_embed.add_field(
                        name="How to Use",
                        value="1. Run PrudaTweak client\n2. Enter your license key when prompted\n3. Or use `!license activate " + license_key + "` in the server",
                        inline=False
                    )
                    
                    await user.send(embed=user_embed)
                except:
                    await ctx.send(f"Note: Could not send DM to {user.mention}. They may have DMs disabled.")
            else:
                data = response.json()
                await ctx.send(f"License generation failed: {data.get('message', 'Unknown error')}")
        except Exception as e:
            print(f"Error generating license: {e}")
            await ctx.send("An error occurred while generating the license.")
        
        return

    if action.lower() == "revoke":
        if len(args) == 0:
            await ctx.send("Please provide a license key. Usage: `!license revoke PRUDA-XXXX-XXXX-XXXX`")
            return
        
        license_key = args[0]
        
        try:
            # Get the license ID first
            response = requests.get(f"{API_URL}/licenses")
            if response.status_code != 200:
                await ctx.send("Could not retrieve licenses.")
                return
            
            licenses = response.json()
            license_data = next((lic for lic in licenses if lic["licenseKey"] == license_key), None)
            
            if not license_data:
                await ctx.send("License not found.")
                return
            
            # Revoke the license
            response = requests.put(f"{API_URL}/licenses/{license_data['id']}", json={
                "status": "revoked"
            })
            
            if response.status_code == 200:
                embed = discord.Embed(
                    title="License Revoked",
                    description=f"License `{license_key}` has been revoked.",
                    color=0xD83B01  # Red/Orange
                )
                await ctx.send(embed=embed)
            else:
                data = response.json()
                await ctx.send(f"Failed to revoke license: {data.get('message', 'Unknown error')}")
        except Exception as e:
            print(f"Error revoking license: {e}")
            await ctx.send("An error occurred while revoking the license.")
        
        return

    if action.lower() == "list":
        try:
            response = requests.get(f"{API_URL}/licenses")
            if response.status_code != 200:
                await ctx.send("Could not retrieve licenses.")
                return
            
            licenses = response.json()
            
            if not licenses:
                await ctx.send("No licenses found.")
                return
            
            # Create paginated embeds (max 10 licenses per page)
            licenses_per_page = 5
            pages = []
            
            for i in range(0, len(licenses), licenses_per_page):
                page_licenses = licenses[i:i+licenses_per_page]
                
                embed = discord.Embed(
                    title="License List",
                    description=f"Showing {i+1}-{min(i+licenses_per_page, len(licenses))} of {len(licenses)} licenses",
                    color=0x0078D4
                )
                
                for license in page_licenses:
                    status_emoji = "✅" if license["status"] == "active" else "❌" if license["status"] == "revoked" else "⚠️"
                    user_info = f"User ID: {license['userId']}" if license['userId'] else "No user assigned"
                    expiry_date = datetime.datetime.fromisoformat(license["expiresAt"].replace('Z', '+00:00')) if license["expiresAt"] else "Never"
                    expiry_str = expiry_date if isinstance(expiry_date, str) else expiry_date.strftime("%Y-%m-%d")
                    
                    embed.add_field(
                        name=f"{status_emoji} {license['licenseKey']}",
                        value=f"Status: {license['status'].capitalize()}\nExpires: {expiry_str}\n{user_info}",
                        inline=False
                    )
                
                pages.append(embed)
            
            # If only one page, just send it
            if len(pages) == 1:
                await ctx.send(embed=pages[0])
                return
            
            # Otherwise set up pagination
            current_page = 0
            message = await ctx.send(embed=pages[current_page])
            
            # Add reactions for pagination
            await message.add_reaction("◀️")
            await message.add_reaction("▶️")
            
            def check(reaction, user):
                return user == ctx.author and str(reaction.emoji) in ["◀️", "▶️"] and reaction.message.id == message.id
            
            while True:
                try:
                    reaction, user = await bot.wait_for("reaction_add", timeout=60.0, check=check)
                    
                    if str(reaction.emoji) == "▶️" and current_page < len(pages) - 1:
                        current_page += 1
                        await message.edit(embed=pages[current_page])
                        await message.remove_reaction(reaction, user)
                    elif str(reaction.emoji) == "◀️" and current_page > 0:
                        current_page -= 1
                        await message.edit(embed=pages[current_page])
                        await message.remove_reaction(reaction, user)
                    else:
                        await message.remove_reaction(reaction, user)
                except asyncio.TimeoutError:
                    break
        except Exception as e:
            print(f"Error listing licenses: {e}")
            await ctx.send("An error occurred while retrieving licenses.")
        
        return

# Config command for setting up the bot
@bot.command(name="config")
@commands.has_permissions(administrator=True)
async def config_command(ctx, setting=None, value=None):
    if setting is None:
        embed = discord.Embed(
            title="Bot Configuration",
            description="Current configuration:",
            color=0x0078D4
        )
        
        admin_role = "Not set"
        if config["admin_role_id"]:
            role = ctx.guild.get_role(config["admin_role_id"])
            admin_role = role.name if role else f"Unknown (ID: {config['admin_role_id']})"
        
        license_role = "Not set"
        if config["license_role_id"]:
            role = ctx.guild.get_role(config["license_role_id"])
            license_role = role.name if role else f"Unknown (ID: {config['license_role_id']})"
        
        embed.add_field(name="Admin Role", value=admin_role, inline=False)
        embed.add_field(name="License Role", value=license_role, inline=False)
        embed.add_field(name="Webhook URL", value=config["webhook_url"] or "Not set", inline=False)
        
        embed.add_field(
            name="Commands",
            value="```\n!config admin_role @role\n!config license_role @role\n!config webhook_url <url>\n```",
            inline=False
        )
        
        await ctx.send(embed=embed)
        return
    
    if setting.lower() == "admin_role":
        if not ctx.message.role_mentions:
            await ctx.send("Please mention a role. Usage: `!config admin_role @role`")
            return
        
        role = ctx.message.role_mentions[0]
        config["admin_role_id"] = role.id
        save_config(config)
        await ctx.send(f"Admin role set to {role.name}")
    
    elif setting.lower() == "license_role":
        if not ctx.message.role_mentions:
            await ctx.send("Please mention a role. Usage: `!config license_role @role`")
            return
        
        role = ctx.message.role_mentions[0]
        config["license_role_id"] = role.id
        save_config(config)
        await ctx.send(f"License role set to {role.name}")
    
    elif setting.lower() == "webhook_url":
        if not value:
            await ctx.send("Please provide a webhook URL. Usage: `!config webhook_url <url>`")
            return
        
        config["webhook_url"] = value
        save_config(config)
        await ctx.send("Webhook URL updated")
    
    else:
        await ctx.send("Unknown setting. Available settings: `admin_role`, `license_role`, `webhook_url`")

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("You don't have permission to use this command.")
    elif isinstance(error, commands.CommandNotFound):
        pass  # Ignore command not found errors
    else:
        print(f"Command error: {error}")

# Start the bot
if __name__ == "__main__":
    if TOKEN == "YOUR_DISCORD_BOT_TOKEN":
        print("Please set your Discord bot token in the script")
        print("You can get a token from https://discord.com/developers/applications")
    else:
        bot.run(TOKEN)