import random
import threading
import time
import pyautogui
import keyboard
from pynput.mouse import Listener, Button
import os
import json
import requests
import platform
import uuid
import hashlib
import sys
import traceback
from PIL import Image, ImageDraw
try:
    from pystray import Icon, MenuItem, Menu
except ImportError:
    print("pystray module not found. Make sure to run install_requirements.bat first.")
    sys.exit(1)

# Application constants
VERSION = "1.0.5"
CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".prudatweak")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
LICENSE_SERVER = "http://localhost:5000/api"  # Change to your actual server URL in production

# Script state
running = False  # Start with script disabled until license is verified
alive = True
right_mouse_pressed = False

# Hotkeys
kill_script_keybind = "end"
toggle_running_keybind = "^"

# Screen center
screen_width, screen_height = pyautogui.size()
x, y = screen_width // 2, screen_height // 2

# Console colors
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
BLUE = "\033[94m"
MAGENTA = "\033[95m"
CYAN = "\033[96m"
RESET = "\033[0m"

# Error logging
def log_error(message):
    try:
        log_dir = os.path.join(CONFIG_DIR, "logs")
        os.makedirs(log_dir, exist_ok=True)
        log_file_path = os.path.join(log_dir, "error_log.txt")
        with open(log_file_path, "a") as log_file:
            log_file.write(f"{time.ctime()} - ERROR: {message}\n")
    except Exception as e:
        print(f"{RED}Failed to write to log file: {e}{RESET}")

# Get hardware ID (HWID)
def get_hwid():
    try:
        # Collect system information
        system_info = platform.system()
        machine = platform.machine()
        processor = platform.processor()
        node = platform.node()
        
        # Create a unique identifier based on machine-specific details
        system_id = f"{system_info}:{machine}:{processor}:{node}"
        
        # Use MAC address as additional identifier
        mac = uuid.getnode()
        
        # Combine and hash the information
        combined = f"{system_id}:{mac}"
        hwid = hashlib.md5(combined.encode()).hexdigest().upper()
        
        # Format as XX-XX-XX-XX (for readability)
        return '-'.join([hwid[i:i+2] for i in range(0, 8, 2)])
    except Exception as e:
        log_error(f"Failed to generate HWID: {e}")
        # Fallback to a simple machine ID if proper HWID generation fails
        return hashlib.md5(platform.node().encode()).hexdigest()[:8].upper()

# Verify license with server
def verify_license(license_key):
    if not license_key:
        return {"success": False, "message": "No license key provided"}
    
    try:
        response = requests.post(
            f"{LICENSE_SERVER}/licenses/verify",
            json={"licenseKey": license_key}
        )
        
        if response.status_code == 200:
            data = response.json()
            if data.get("success"):
                print(f"{GREEN}License valid: {data.get('message')}{RESET}")
                
                # Check if HWID is already set and matches
                if data.get("hwid"):
                    current_hwid = get_hwid()
                    if data.get("hwid") != current_hwid:
                        return {
                            "success": False, 
                            "message": f"License is tied to a different machine. Contact support."
                        }
                
                return data
            else:
                print(f"{RED}License invalid: {data.get('message')}{RESET}")
                return data
        else:
            error_msg = f"Server returned status code {response.status_code}"
            print(f"{RED}{error_msg}{RESET}")
            return {"success": False, "message": error_msg}
    except requests.RequestException as e:
        error_msg = f"Failed to connect to license server: {e}"
        print(f"{RED}{error_msg}{RESET}")
        return {"success": False, "message": error_msg}
    except Exception as e:
        log_error(f"Verification error: {e}")
        error_msg = f"Unexpected error: {e}"
        print(f"{RED}{error_msg}{RESET}")
        return {"success": False, "message": error_msg}

# Activate license with HWID
def activate_license(license_key):
    if not license_key:
        return {"success": False, "message": "No license key provided"}
    
    try:
        hwid = get_hwid()
        response = requests.post(
            f"{LICENSE_SERVER}/licenses/activate",
            json={"licenseKey": license_key, "hwid": hwid}
        )
        
        if response.status_code == 200:
            data = response.json()
            if data.get("success"):
                print(f"{GREEN}License activated successfully: {data.get('message')}{RESET}")
                return data
            else:
                print(f"{RED}License activation failed: {data.get('message')}{RESET}")
                return data
        else:
            error_msg = f"Server returned status code {response.status_code}"
            print(f"{RED}{error_msg}{RESET}")
            return {"success": False, "message": error_msg}
    except requests.RequestException as e:
        error_msg = f"Failed to connect to license server: {e}"
        print(f"{RED}{error_msg}{RESET}")
        return {"success": False, "message": error_msg}
    except Exception as e:
        log_error(f"Activation error: {e}")
        error_msg = f"Unexpected error: {e}"
        print(f"{RED}{error_msg}{RESET}")
        return {"success": False, "message": error_msg}

# Ensure config directory exists
def ensure_config_dir():
    os.makedirs(CONFIG_DIR, exist_ok=True)

# Save configuration
def save_config(config_data):
    ensure_config_dir()
    with open(CONFIG_FILE, "w") as f:
        json.dump(config_data, f, indent=4)

# Load configuration
def load_config():
    ensure_config_dir()
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except json.JSONDecodeError:
            log_error("Invalid config file format")
            return {}
        except Exception as e:
            log_error(f"Failed to load config: {e}")
            return {}
    return {}

# Tray icon creation
def create_tray_icon():
    def create_image(color):
        # Create a simple colored square icon
        image = Image.new("RGB", (64, 64), color)
        draw = ImageDraw.Draw(image)
        return image

    def update_icon():
        icon.icon = create_image("green" if running else "red")

    def toggle_running_action(icon, item):
        global running
        running = not running
        update_icon()
        print(f"{GREEN if running else RED}Script {'enabled' if running else 'disabled'}{RESET}")

    def exit_script(icon, item):
        kill_script()

    # Create menu
    menu = Menu(
        MenuItem("Toggle Script (^)", toggle_running_action),
        MenuItem("Exit (END)", exit_script)
    )

    # Create icon
    icon = Icon("PrudaTweak", create_image("red"), f"PrudaTweak v{VERSION}", menu)
    update_icon()
    
    try:
        icon.run()
    except Exception as e:
        log_error(f"Tray icon error: {e}")
        print(f"{RED}Failed to create tray icon: {e}{RESET}")

# Mouse click detection
def on_click(x, y, button, pressed):
    global right_mouse_pressed
    if button == Button.right:
        right_mouse_pressed = pressed

# Main check loop
def check():
    while alive:
        if running and right_mouse_pressed:
            try:
                center_x, center_y = screen_width // 2, screen_height // 2
                if center_x < 0 or center_y < 0 or center_x >= screen_width or center_y >= screen_height:
                    raise ValueError("Coordinates out of screen bounds.")

                # Get pixel color at screen center
                color = pyautogui.pixel(center_x, center_y)
                r, g, b = color
                
                # Check for red color (Pruda detection logic)
                if r >= 180 and g < 100 and b < 100:
                    pyautogui.mouseDown()
                    time.sleep(random.uniform(0.001, 0.005))
                    pyautogui.mouseUp()
            except Exception as e:
                log_error(f"Color check error: {e}")
                print(f"{RED}Error during color check: {e}{RESET}")
        time.sleep(0.001)  # Small sleep to prevent CPU overuse

# Hotkey setup
def setup_hotkeys():
    try:
        keyboard.add_hotkey(toggle_running_keybind, toggle_running_action)
        keyboard.add_hotkey(kill_script_keybind, kill_script)
        keyboard.wait()
    except Exception as e:
        log_error(f"Hotkey setup error: {e}")
        print(f"{RED}Error setting up hotkeys: {e}{RESET}")

# Toggle script status
def toggle_running_action():
    global running
    running = not running
    print(f"{GREEN if running else RED}Script {'enabled' if running else 'disabled'}{RESET}")

# Kill script
def kill_script():
    global alive
    alive = False
    try:
        if mouse_listener.is_alive():
            mouse_listener.stop()
    except:
        pass
    print(f"{RED}Exiting script...{RESET}")
    os._exit(0)

# Main function
def main():
    global running, mouse_listener
    
    # Print welcome message
    print(f"{CYAN}╔═══════════════════════════════════════╗{RESET}")
    print(f"{CYAN}║{RESET}    {MAGENTA}PrudaTweak Licensing Client v{VERSION}{RESET}    {CYAN}║{RESET}")
    print(f"{CYAN}╚═══════════════════════════════════════╝{RESET}")
    
    # Set up mouse listener
    mouse_listener = Listener(on_click=on_click)
    mouse_listener.start()
    
    # Load configuration
    config = load_config()
    license_key = config.get("license_key", "")
    
    # Check if we have a saved license key
    if not license_key:
        print(f"{YELLOW}No license key found. Please enter your license key below.{RESET}")
        license_key = input("License Key: ").strip()
        
        if not license_key:
            print(f"{RED}No license key provided. Exiting.{RESET}")
            return
    
    # Verify license
    license_data = verify_license(license_key)
    
    if not license_data.get("success"):
        # License verification failed
        print(f"{RED}License verification failed: {license_data.get('message')}{RESET}")
        
        # Check if we should try to activate
        if "hwid" in license_data.get("message", "").lower():
            print(f"{YELLOW}This license requires activation with your hardware ID.{RESET}")
            response = input("Would you like to activate this license on this machine? (y/n): ").strip().lower()
            
            if response == 'y':
                # Activate the license with HWID
                activation_data = activate_license(license_key)
                
                if activation_data.get("success"):
                    # Save the license key to config
                    config["license_key"] = license_key
                    save_config(config)
                    
                    # License activated successfully
                    print(f"{GREEN}License activated successfully. PrudaTweak is now ready to use.{RESET}")
                    print(f"{YELLOW}Use '{toggle_running_keybind}' key to toggle the script on/off.{RESET}")
                    print(f"{YELLOW}Use '{kill_script_keybind}' key to exit the script.{RESET}")
                    
                    # Enable the script
                    running = True
                else:
                    print(f"{RED}License activation failed. Exiting.{RESET}")
                    time.sleep(5)
                    return
            else:
                print(f"{RED}License not activated. Exiting.{RESET}")
                time.sleep(5)
                return
        else:
            print(f"{RED}Invalid license. Exiting in 5 seconds...{RESET}")
            time.sleep(5)
            return
    else:
        # License is valid
        config["license_key"] = license_key
        save_config(config)
        
        # Show license information
        expires_at = license_data.get("expires", "Never")
        if isinstance(expires_at, str) and expires_at != "Never":
            expires_at = expires_at.split('T')[0]  # Format date for display
            
        status = license_data.get("status", "Unknown")
        
        print(f"{GREEN}License verified successfully!{RESET}")
        print(f"{CYAN}Status: {status}{RESET}")
        print(f"{CYAN}Expires: {expires_at}{RESET}")
        print(f"{CYAN}HWID: {get_hwid()}{RESET}")
        print(f"{YELLOW}Use '{toggle_running_keybind}' key to toggle the script on/off.{RESET}")
        print(f"{YELLOW}Use '{kill_script_keybind}' key to exit the script.{RESET}")
        
        # Enable the script
        running = True
    
    # Start the threads
    icon_thread = threading.Thread(target=create_tray_icon, daemon=True)
    icon_thread.start()
    
    check_thread = threading.Thread(target=check, daemon=True)
    check_thread.start()
    
    # Set up hotkeys and wait for user input
    setup_hotkeys()

# Entry point
if __name__ == "__main__":
    try:
        pyautogui.FAILSAFE = False  # Disable failsafe
        main()
    except KeyboardInterrupt:
        print(f"{RED}Script interrupted by user.{RESET}")
    except Exception as e:
        log_error(f"Unhandled exception: {traceback.format_exc()}")
        print(f"{RED}An unexpected error occurred: {e}{RESET}")
        print(f"{RED}Check the log file for more details.{RESET}")
    finally:
        try:
            if 'mouse_listener' in globals() and mouse_listener.is_alive():
                mouse_listener.stop()
        except:
            pass